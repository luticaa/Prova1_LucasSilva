package com.exercicioPratico.LabProgramacao;
//aplicacao principal
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//anotacao pra informar que é spring
@SpringBootApplication
public class LabProgramacaoApplication {
//funcao principal que roda a aplicacao
	public static void main(String[] args) {
		SpringApplication.run(LabProgramacaoApplication.class, args);
	}

}
